# CyberShield – AI Cybersecurity Agent

A beginner-friendly defensive cybersecurity awareness demo built with Streamlit.

## Run on your laptop
1. Install Python.
2. Open a terminal in this folder.
3. Run: `pip install -r requirements.txt`
4. Run: `streamlit run app.py`

## Publish a shareable demo link
1. Upload `app.py` and `requirements.txt` to a GitHub repository.
2. Open https://share.streamlit.io/
3. Sign in with GitHub and choose the repository.
4. Set the main file path to `app.py`, then deploy.
5. Streamlit will provide a public app URL.

## Features
- Basic URL pattern review
- Phishing-message indicator review
- Simple system-log keyword review

This is an educational heuristic demo, not a professional security scanner. It does not fetch URLs, execute files, or confirm that a site is safe.
